 @include('include.header')

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box d-flex align-items-center justify-content-between">
                                <h4 class="mb-0 font-size-18">EMI</h4>

                                <div class="page-title-right">
                                    <ol class="breadcrumb m-0">
                                        <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboard</a></li>
                                        <li class="breadcrumb-item active">EMI</li>
                                    </ol>
                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- end page title -->
                   
                   
                
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <table id="" class="table table-striped table-bordered table-sm" cellspacing="0" width="100%">
                                        <thead>
                                            <tr>
                                                <th>Installment</th>
                                                <th>EMI Date</th>
                                                <th>Amount</th>
                                                <th>Penalty</th>
                                                <th>Payment Status</th>
                                                <th>Payment Date</th>
                                                <th>Pay Now</th>
                                               
                                                
                                            </tr>
                                        </thead>
                                    
                                    
                                        <tbody>
                                            @php $i=1;@endphp
                                            @foreach($user_emi as $val)
                                            <tr>
                                                <td>{{$i++}}</td>
                                                <td><input class="form-control number" type="text" name="" value="{{$val->emi_date}}" readonly> </td>
                                                <td><input class="form-control number" type="text" name="" value="{{$val->emi_amount}}" readonly> </td>
                                                <td></td>
                                                <td>{{$val->pad_status}}</td>
                                                <td>@if($val->pad_date!='0000-00-00'){{$val->pad_date}}@endif</td>
                                                <td> @if($val->pad_status=='no') <div class="form-row align-items-center">
                                                   <a href="{{url('pad_emi/'.$val->id.'/'.$val->emi_amount)}}"><div class="col-auto">
                                                        <button type="submit" id="submit_button" class="btn btn-success mb-2 waves-effect waves-light">Pay Now</button>
                                                    </div></a>
                                                @endif</td>
                                            </tr>
                                           
                                            @endforeach
                                        </tbody>
                                    </table>
                                </form>
                                </div> <!-- end card body-->
                            </div> <!-- end card -->
                        </div><!-- end col-->
                    </div>


                </div> <!-- container-fluid -->
            </div>
            <!-- End Page-content -->

           @include('include.footer')
       <script type="text/javascript">

      //$('#myDiv').hide();
       function val_check(val) {
                if(val=='emi'){
                     $('#myDiv').show();

                }else{
                     $('#myDiv').hide();

                }
                 
             }
 
</script>
<script type="text/javascript">
              function pan_get_name(){
                val_check();
                var ifsc = $( "#ifsc" ).val();
                var acc_no = $( "#acc_no" ).val();
                    $.ajax({
                         type: "GET",
                         enctype: 'multipart/form-data',
                         url: 'get_bank_details',
                         data: {ifsc:ifsc,acc:acc_no},
                         dataType: 'json',
                         success: function (res) {
                             
                              if(res.status=='false'){
                                $('#acc_v').html('Account number not valid. please enter valid account number');
                            }else{
                            $('#verify').prop('disabled', true);
                            $('#submit_button').prop('disabled', false);
                            $('#ifsc').attr('readonly', true);
                            $('#acc_no').attr('readonly', true);
                            $('.myDiv').show();
                            $('#acc_v').html('');

                            document.getElementById('bank_name').value=res.bank_name; 
                            document.getElementById('branch').value=res.branch; 
                            document.getElementById('bank_address').value=res.bank_address; 
                            document.getElementById('full_name').value=res.full_name; 
                            }
                         },
                         error: function (e) {
                             console.log("ERROR : ", e);
                             console.log(e.responseText);
                         }
                     });
                 }
       </script>